<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<?php
session_start();
$userId = 1;
$_SESSION["fname"] = "vishal sharma";
$_SESSION["mobile"] = "9926701109";
$_SESSION["email"] = "vishalsharma.developer@gmail.com";
$order_id =  "ORDS" . rand(10000,99999999).'_'.$userId  ;
?>
  
<div class="container-fluid text-center">    
  <div class="row content">
        <!-- *********************** -->
        <div class="home-page-icon-boxes">
        <div class="container">
            <div class="row" id="questContainer">
                  <div class="col-xl-6 col-md-6 col-xs-12 col-sm-12 text-left">
                    <h3>Paymant Form</h3>
                    
                      <div class="form-group">
                  <label for="email">Name:</label>
                  <input type="text" readonly class="form-control"  value="<?php echo $_SESSION['fname']?>">
              </div>
              <div class="form-group">
                  <label for="email">Contact No:</label>
                  <input type="text" readonly class="form-control"  value="<?php echo $_SESSION['mobile']?>">
              </div>
              <div class="form-group">
                  <label for="email">Your Email:</label>
                  <input type="text" readonly class="form-control"  value="<?php echo $_SESSION['email']?>">
              </div>
            
             
            <form method="post" action="pgRedirect.php">
               <div class="form-group">
                  <label for="TXN_AMOUNT">Package Amount(Rs):</label>
                  <input type="text" class="form-control" id="TXN_AMOUNT" name="TXN_AMOUNT"  value="1">
               </div>
              <div class="form-group">
                  <label for="email">Order Id:</label>
                   <input type="text" class="form-control" id="ORDER_ID" name="ORDER_ID" value="<?php 
                   echo $order_id ?>">
               </div>
               <div class="form-group">
                  <label for="email">Custmer Id:</label>
                  <input type="text" class="form-control" id="CUST_ID" name="CUST_ID"   value="1">
               </div>
               <div class="form-group">
                  <input type="hidden"  id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail109">
               </div>
               <div class="form-group">
                <input type="hidden"  id="CHANNEL_ID" tabindex="4" maxlength="12" size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">              
              </div>
               <div class="form-group">
                     <input class="btn" value="CheckOut" type="submit"  onclick="">
               </div>
            </form> 
          </div>
        </div>
      </div>
    </div>
        <!-- *********************** -->
  </div>
</div>

<footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>

</body>
</html>
