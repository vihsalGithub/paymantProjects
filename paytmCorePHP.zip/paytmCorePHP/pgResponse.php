<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");

// following files need to be included
require_once("./lib/config_paytm.php");
require_once("./lib/encdec_paytm.php");


/*****************************"Email Sent Message"*********************************/
session_start();
include("../admin/connect.php"); 
//include("login_check.php");
$userselect1=mysqli_query($conn,"SELECT * FROM  ".TBL_USERS."  WHERE id = ".$_SESSION['userid']." ");
$userdata1=mysqli_fetch_array($userselect1);
//print_r($userdata1); 
$user_name = $userdata1['first_name'].' '.$userdata1['last_name'];
 $user_email = $userdata1['user_email'];
$sub="Your deposit is successful. Start playing now!";
$message='<body>
<div style="width: 600px;margin: 0 auto;border: 1px solid #ccc;float: none; font-family:Arial, Helvetica, sans-serif;">
<div style="background:#1c1c1c; display:inline-block; width:582px; padding:10px 10px;">
<h1 style="float: left;color: #fff;margin: 0;padding: 0;font-size: 22px;text-transform: capitalize;">cricket<strong style="color:#bc2024 !important;">4</strong>all</h1>
<strong style="float:right; color:#fff;">10k + users</strong>
</div>
<div style="background:#fff; display:inline-block; width:560px; padding:20px;">

<h2 style="text-align: center;">Hi '.$user_name.', </h2>

<p style="text-align: center;line-height: 26px;font-size: 18px;">You`re all set! Rs.'.$_POST['amount'].' has been deposited in your Cricket4all Account.</p>

<a href="https://cricket4all.com/Mydeposit.php" target="_blank">CHECK ACCOUNT BALANCE</a>
</div> 
</div>
</body>';
$headers ="From: Cricket4all Notification <info@cricket4all.com> \r\n";
$headers .="MIME-Version: 1.0\r\n";
$headers .="Content-type: text/html\r\n";


/***********************************************************************/
$paytmChecksum = "";
$paramList = array();
$isValidChecksum = "FALSE";
$paramList = $_POST;
$paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : ""; 
$isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum); 
if($isValidChecksum == "TRUE") {
	if ($_POST["STATUS"] == "TXN_SUCCESS") {
		if (isset($_POST) && count($_POST)>0 )
		{ 
			if($_SESSION['userid']){
				$user_id = $_SESSION['userid'] ;
			}else{
				$user_id = explode("_",$_POST['ORDERID'])[1] ;
			}
			$current_balance = $_POST['TXNAMOUNT'] ;
			$invoiceid = $_POST['ORDERID'];
			$payment_ref_id = $_POST['TXNID'];
				$string = $_POST['CURRENCY'].'/'.$_POST['TXNDATE'].'/'.$_POST['RESPCODE'].'/'.$_POST['GATEWAYNAME'].'/'.$_POST['BANKTXNID'].'/'.$_POST['BANKNAME'] ;
			$desc_text = strval($string);
			$pay_status = "success";
			$amount_type = 'add_funds';
			/*foreach($_POST as $paramName => $paramValue) {
					echo "<br/>" . $paramName . " = " . $paramValue;
			}*/
			$sql = 'INSERT INTO tbl_balance (user_id, invoiceid, payment_ref_id, amount_type, current_balance, desc_text, pay_status) values ("'.$user_id.'", "'.$invoiceid.'", "'.$payment_ref_id.'", "'.$amount_type.'", "'.$current_balance.'", "'.$desc_text.'", "'.$pay_status.'")';

			 echo $sql ; die;

			if (mysqli_query($conn, $sql)) {
			    $emailsu=mail($user_email,$sub,$message,$headers);
				header('Location: https://www.cricket4all.com/mydeposit.php');
			} else {
			    //echo "Error: " . $sql . "<br>" . mysqli_error($conn);
				header('Location: https://www.cricket4all.com/mydeposit.php?id=1');
			}
		}
	}
	else {
		header('Location: https://www.cricket4all.com/add_funds.php');
	}

}
else {
	header('Location: https://www.cricket4all.com/mydeposit.php?id=3');
}

?>