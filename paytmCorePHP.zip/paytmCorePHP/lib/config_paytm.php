<?php


define('PAYTM_ENVIRONMENT', 'TEST');
define('PAYTM_MERCHANT_KEY', 'S&zX#ajK8mQTVYva');
define('PAYTM_MERCHANT_MID', 'ltDxyr84225412161515');  
define('PAYTM_MERCHANT_WEBSITE', 'WEBSTAGING'); 



/*define('PAYTM_ENVIRONMENT', 'PROD'); 
define('PAYTM_MERCHANT_KEY', '************'); 
define('PAYTM_MERCHANT_MID', '*********'); 
define('PAYTM_MERCHANT_WEBSITE', 'DEFAULT'); */

$PAYTM_STATUS_QUERY_NEW_URL='https://securegw-stage.paytm.in/merchant-status/getTxnStatus';
$PAYTM_TXN_URL='https://securegw-stage.paytm.in/theia/processTransaction';
if (PAYTM_ENVIRONMENT == 'PROD') {
	$PAYTM_STATUS_QUERY_NEW_URL='https://securegw.paytm.in/merchant-status/getTxnStatus';
	$PAYTM_TXN_URL='https://securegw.paytm.in/theia/processTransaction';
}

//echo $PAYTM_STATUS_QUERY_NEW_URL ; die;

define('PAYTM_REFUND_URL', '');
define('PAYTM_STATUS_QUERY_URL', $PAYTM_STATUS_QUERY_NEW_URL);
define('PAYTM_STATUS_QUERY_NEW_URL', $PAYTM_STATUS_QUERY_NEW_URL);
define('PAYTM_TXN_URL', $PAYTM_TXN_URL);

?>
