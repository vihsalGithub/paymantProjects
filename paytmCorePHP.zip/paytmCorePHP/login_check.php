<?php
	if(isset($_SESSION['adminid']))	
	{
	//header("Location: index.php");
	}
	else
	{
	 header("Location: login.php");
	}
?>

