<?php 

//////////// site url ///////////////
define("SITE_URL","https://www.cricket4all.com/");
$player_image_url='';
$player_image_url="https://www.cricket4all.com/player_image_upload/";
$team_image_url='';
$team_image_url="https://www.cricket4all.com/team_logo_upload/";
//////////// secret key useing by apps ///////////////
$secretkey="cricket4all";
//////////////////////////////////////////////////////
/////////////// code for set timezone ///////////
date_default_timezone_set('Asia/Kolkata'); 
$script_tz = date_default_timezone_get();
if (strcmp($script_tz, ini_get('date.timezone'))){
   // echo 'Script timezone differs from ini-set timezone.';
} else {
    //echo 'Script timezone and ini-set timezone match.';
}

ob_start();
///////////// live server ///////
$servername = "localhost";
$username = "cricket4_root18";
$password = "*t^SR^Y#nz1{";
/////////////////////////////

// Create connection
$conn = mysqli_connect($servername, $username, $password);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
//echo "Connected successfully";

mysqli_select_db($conn,"cricket4_liveCricket4All");

define("TBL_ADMIN","tbl_admin");
define("TBL_USERS","tbl_user");
define("TBL_TEAMS","tbl_teams");
define("TBL_PLAYERS","tbl_players");
define("TBL_LEAGUES","tbl_leagues");
define("TBL_LEAGUE_TEAMS","tbl_league_teams");
define("TBL_LEAGUE_TEAMS_PLAYER","tbl_league_teams_player");
define("TBL_CONTESTS","tbl_contests");
define("TBL_MATCHES","tbl_matches");
define("TBL_USERS_TEAMNAME","tbl_user_teamname");
define("TBL_SETTING","tbl_setting");
define("TBL_CONFIRM","tbl_confirm");
define("TBL_SETTING_T20","tbl_setting_t20");
define("TBL_SETTING_ODI","tbl_setting_odi");
define("TBL_SETTING_TEST","tbl_setting_test");
define("TBL_POINTS_TABLE","tbl_points_table");
define("TBL_CONTEST_USERS_TEAMS","tbl_contest_users_teams");
define("TBL_BALANCE","tbl_balance");
define("TBL_CONTEST_JOIN","tbl_contests_join");
define("COUNTRIES","countries");
define("STATES","states");
define("TBL_PANCARD","tbl_pancard");
define("TBL_BANK_DETAILS","tbl_bank_details");
define("TBL_BONUS","tbl_bonus");
define("TBL_NOTIFICATION","tbl_notification");
define("TBL_FORGOT_PASS","tbl_forgot_pass");
define("TBL_CONTESTWINAMTS","tbl_contestwinamts");
define("TBL_INVITE_FRIENDS","tbl_invite_friends");
define("TBL_MOBILE_VERIFY","tbl_mobile_verify");
define("TBL_BANNER_PROMO","tbl_banner_promo");
define("TBL_CRICKET_CONTEST","tbl_cricket_contest");
define("TBL_CRICKET_CONTESTS_JOIN","tbl_cricket_contests_join");
define("TBL_SUBSCRIBE","tbl_subscribe");
define("TBL_CONTEST_JOIN_BAL_TYPE","tbl_contest_join_bal_type");
define("TBL_WIN_LUCKY_DRAW","tbl_win_lucky_draw");
define("TBL_MOBILE_DOWNLOAD_APPS","tbl_mobile_download_apps");
define("TBL_ADD_CONTEST","tbl_add_contests");
define("TBL_ADD_CONTESTWINAMTS","tbl_add_contestwinamts");


define("TBL_CONTESTS_FREE","tbl_contests_free");

define("TBL_CONTESTS_FREE_JOIN","tbl_contests_free_join");

?>
